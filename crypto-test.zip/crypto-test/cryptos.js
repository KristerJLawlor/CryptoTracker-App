export const cryptos =
[
  {
    symbol: "BTC",
    name: "Bitcoin",
    price_usd: 19335, 
    percent_change_usd_last_24_hours: 2.2
  },
   {
    symbol: "ETH",
    name: "Ethereum",
    price_usd: 19000, 
    percent_change_usd_last_24_hours: 0.2
  },
     {
    symbol: "XRP",
    name: "XRP",
    price_usd: 1900, 
    percent_change_usd_last_24_hours: 5.2
  },
];