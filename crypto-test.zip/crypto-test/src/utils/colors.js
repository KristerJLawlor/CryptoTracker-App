export const colors = {

  white: '#fff',
  darkBlue: '#012345',
}